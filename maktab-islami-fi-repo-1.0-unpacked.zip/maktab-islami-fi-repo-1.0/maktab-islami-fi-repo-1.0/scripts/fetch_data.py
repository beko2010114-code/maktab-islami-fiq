#!/usr/bin/env python3
"""Fetch reproducible, attributed Quran/tafsir data for the offline Android build."""
from pathlib import Path
from urllib.request import Request, urlopen
import json, time

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'app' / 'src' / 'main' / 'assets' / 'data'
DATA.mkdir(parents=True, exist_ok=True)

def get(url, timeout=60):
    req = Request(url, headers={'User-Agent':'Maktab-Islami-Fiqh/5.0 data-builder'})
    with urlopen(req, timeout=timeout) as r:
        return r.read()

def save(url, path):
    print('GET', url)
    data = get(url)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_bytes(data)
    tmp.replace(path)
    print('  ->', path, len(data), 'bytes')

# Quran text: quran-json 3.1.2, whose README identifies the Uthmani text source as
# The Noble Qur'an Encyclopedia. Keep source attribution in the app and manifest.
save('https://cdn.jsdelivr.net/npm/quran-json@3.1.2/dist/quran.json', DATA/'quran.json')

# QuranEnc Arabic tafsir datasets. The API terms permit republishing if content is
# not modified and publisher/source/version are retained.
for key, filename, title in [
    ('arabic_moyassar', 'tafsir_muyassar.json', 'التفسير الميسر'),
    ('arabic_saadi', 'tafsir_saadi.json', 'تفسير السعدي'),
]:
    all_surahs = {}
    for sura in range(1, 115):
        url = f'https://quranenc.com/api/v1/translation/sura/{key}/{sura}'
        try:
            all_surahs[str(sura)] = json.loads(get(url).decode('utf-8'))
        except Exception as e:
            raise RuntimeError(f'Failed {key} sura {sura}: {e}')
        if sura % 10 == 0:
            print(f'  {key}: {sura}/114')
        time.sleep(0.03)
    (DATA/filename).write_text(json.dumps({'source':'QuranEnc.com','translation_key':key,'title':title,'version_note':'Use current version supplied by QuranEnc at build time','surahs':all_surahs}, ensure_ascii=False, separators=(',',':')), encoding='utf-8')

manifest = {
  'quran': {
    'dataset':'quran-json 3.1.2',
    'text_source':'The Noble Qur\'an Encyclopedia',
    'url':'https://github.com/risan/quran-json',
    'cdn':'https://cdn.jsdelivr.net/npm/quran-json@3.1.2/dist/quran.json'
  },
  'tafsir': [
    {'name':'التفسير الميسر','provider':'QuranEnc.com','key':'arabic_moyassar','url':'https://quranenc.com/ar/browse/arabic_moyassar/'},
    {'name':'تفسير السعدي','provider':'QuranEnc.com','key':'arabic_saadi','url':'https://quranenc.com/en/browse/arabic_saadi/'}
  ],
  'hadith': {
    'provider':'fawazahmed0/hadith-api',
    'mode':'remote-by-default',
    'url':'https://github.com/fawazahmed0/hadith-api',
    'note':'The app uses a remote API for the large hadith corpus rather than silently bundling third-party bulk text.'
  }
}
(DATA/'sources.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print('Data build complete.')
